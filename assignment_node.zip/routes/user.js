const express = require('express');

const router = express.Router();
// Require the controllers
const {
    getUsers,
} = require('../controllers/user');

const { protect, authorize } = require('../middleware/auth');

router.use(protect);

router.route('/').get(getUsers)

module.exports = router;

