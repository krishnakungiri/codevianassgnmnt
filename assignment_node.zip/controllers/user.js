
const User = require('../models/user');

// @desc   Get all user
// @route  GET /api//users
// @access Private/Admin
exports.getUsers = async (req, res) => {
    const allUsers = await User.find({})
        .sort({ createdAt: -1 })

    res.status(200).json({
        success: true,
        data: allUsers
    });
}
